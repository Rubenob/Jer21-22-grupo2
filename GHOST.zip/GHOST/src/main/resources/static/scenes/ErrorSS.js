var ErrorSS = new Phaser.Class({
    Extends: Phaser.Scene,
    initialize: function() {
        Phaser.Scene.call(this, { "key": "ErrorSS" });
    },
    init: function() {		
	},
    preload: function() {
    },
    create: function(datos) { 
    	console.log('create error sin servidor.');
    	this.cameras.main.setBackgroundColor("#CC0000");
	    text_cTe = this.add.text(15, 200, "",{ fontSize: '30px',fill:'#000', fontStyle: 'bold' });
	    text_cTe.setText('ERROR: '+datos.codigoError);
    },
    update: function() {
	}
});