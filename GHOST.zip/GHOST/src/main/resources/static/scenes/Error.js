var Error = new Phaser.Class({
    Extends: Phaser.Scene,
    initialize: function() {
        Phaser.Scene.call(this, { "key": "Error" });
    },
    init: function() {		
	},
    preload: function() {
        this.load.image('error', 'assets/image/pantalla_error.png');
    },
    create: function(datos) { 
		this.errorImage = this.add.image(0,0, 'error').setOrigin(0,0);
    	console.log('create error');
	    text_cTe = this.add.text(15, 200, "",{ fontSize: '30px',fill:'#000', fontStyle: 'bold' });
	    text_cTe.setText(datos.codigoError);
    },
    update: function() {
	}
});