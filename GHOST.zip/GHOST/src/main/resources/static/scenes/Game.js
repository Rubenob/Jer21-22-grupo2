var Game = new Phaser.Class({
    Extends: Phaser.Scene,
    initialize: function() {
        Phaser.Scene.call(this, { "key": "Game" });
    },
    		
    init: function() {},
    
    preload: function() {
       				console.log("Game preload");
       				
       				// Barra de progreso de carga.	
       				
       				/*
       				    Autor del codigo de la barra de carga: Scott Westover
       				    P�gina: https://gamedevacademy.org/creating-a-preloading-screen-in-phaser-3/?a=13
       				    Licencia de uso: Libre
       					GameDev Academy Zenva
						Tutorials on Game Development, Unity, Phaser and HTML5
       				*/
       							    
				    var progressBar = this.add.graphics();
		            var progressBox = this.add.graphics();
		            progressBox.fillStyle(0x99CCFF, 0.8);
		            progressBox.fillRect(240, 270, 320, 50);
		            
		            var width = this.cameras.main.width;
		            var height = this.cameras.main.height;
		            var loadingText = this.make.text({
		                x: width / 2,
		                y: height / 2 - 50,
		                text: 'Cargando...',
		                style: {
		                    font: '20px monospace',
		                    fill: '#ffffff'
		                }
		            });
		            loadingText.setOrigin(0.5, 0.5);
		            
		            var percentText = this.make.text({
		                x: width / 2,
		                y: height / 2 - 5,
		                text: '0%',
		                style: {
		                    font: '18px monospace',
		                    fill: '#ffffff'
		                }
		            });
		            percentText.setOrigin(0.5, 0.5);
		            
		            var assetText = this.make.text({
		                x: width / 2,
		                y: height / 2 + 50,
		                text: '',
		                style: {
		                    font: '18px monospace',
		                    fill: '#ffffff'
		                }
		            });
		            assetText.setOrigin(0.5, 0.5);
		            
		            this.load.on('progress', function (value) {
		                percentText.setText(parseInt(value * 100) + '%');
		                progressBar.clear();
		                progressBar.fillStyle(0xffffff, 1);
		                progressBar.fillRect(250, 280, 300 * value, 30);
		            });
		            
		            this.load.on('fileprogress', function (file) {
		                assetText.setText('Cargando asset: ' + file.key);
		            });
		            this.load.on('complete', function () {
		                progressBar.destroy();
		                progressBox.destroy();
		                loadingText.destroy();
		                percentText.destroy();
		                assetText.destroy();
		            });
            	
					/*
					*
					*
					* Fin barra de carga.
					*
					*
					*/            	
            	
					//map
					this.load.spritesheet('tiles', 'assets/tilemaps/tiles_Iso.png', { frameWidth: 32, frameHeight: 32 });
					this.load.json('map',  'assets/tilemaps/map.json');
					//imagenes objetos
					this.load.image('aceite', 'assets/image/aceite.png');
					this.load.image('almohada', 'assets/image/almohada.png');
					this.load.image('almohadaPlasma', 'assets/image/almohadaPlasma.png');
					this.load.image('arana', 'assets/image/arana.png');
					this.load.image('caja', 'assets/image/caja.png');
					this.load.image('cebolla', 'assets/image/cebolla.png');
					this.load.image('diario', 'assets/image/diario.png');
					this.load.image('estanteria1', 'assets/image/estanteria1.png');
					this.load.image('estanteria2', 'assets/image/estanteria2.png');
					this.load.image('ganzua', 'assets/image/ganzua.png');
					this.load.image('ganzuaInventario', 'assets/image/ganzuaInventario.png');
					this.load.image('jamon', 'assets/image/jamon.png');
					this.load.image('lavabo', 'assets/image/lavabo.png');
					this.load.image('lechuga', 'assets/image/lechuga.png');
					this.load.image('libro1', 'assets/image/libro1.png');
					this.load.image('libro2', 'assets/image/libro2.png');
					this.load.image('libro3', 'assets/image/libro3.png');
					this.load.image('libro4', 'assets/image/libro4.png');
					this.load.image('libroAbierto', 'assets/image/libroAbierto.png');
					this.load.image('llave', 'assets/image/llave.png');
					this.load.image('llave2Inventario', 'assets/image/llave2Inventario.png');
					this.load.image('llave3Inventario', 'assets/image/llave3Inventario.png');
					this.load.image('llaveCajon', 'assets/image/llaveCajon.png');
					this.load.image('llaveInventario', 'assets/image/llaveInventario.png');
					this.load.image('mesaAcero', 'assets/image/mesaAcero.png');
					this.load.image('nota', 'assets/image/nota.png');
					this.load.image('papelera', 'assets/image/papelera.png');
					this.load.image('radiador', 'assets/image/radiador.png');
					this.load.image('radiadorOxidado', 'assets/image/radiadorOxidado.png');
					this.load.image('radiadorPlasma', 'assets/image/radiadorPlasma.png');
					this.load.image('retrete2', 'assets/image/retrete2.png');
					this.load.image('silla', 'assets/image/silla.png');
					this.load.image('sillaRuedas', 'assets/image/sillaRuedas.png');
					this.load.image('sillas', 'assets/image/sillas.png');
					//this.load.image('taburete', 'assets/image/taburete.png');
					this.load.image('taburete2', 'assets/image/taburete2.png');
					this.load.image('vinagre', 'assets/image/vinagre.png');
					this.load.image('posterH', 'assets/image/posterH.png');
					this.load.image('insigniaG8', 'assets/image/insigniaG8.png');

					//player_h
					this.load.spritesheet('player_h', 'assets/spritesheets/player_h/player_h_idel.png', { frameWidth: 32, frameHeight: 82 });
					this.load.json('shapes_player_h', 'assets/spritesheets/player_h/player_h.json');

					//abuelo
					this.load.spritesheet('abuelo', 'assets/spritesheets/abuelo/abuelo_changer.png', { frameWidth: 28, frameHeight: 74 });
					this.load.json('shapes_abuelo', 'assets/spritesheets/abuelo/abuelo.json');

					//mesaFoto
					this.load.spritesheet('mesaFoto', 'assets/spritesheets/mesaFoto/mesaFoto.png', { frameWidth: 73, frameHeight: 66 });
					this.load.json('shapes_mesaFoto', 'assets/spritesheets/mesaFoto/mesaFoto.json');

					//cama
					this.load.spritesheet('cama1', 'assets/spritesheets/cama/cama1.png', { frameWidth: 88, frameHeight: 72 });
					this.load.json('shapes_cama1', 'assets/spritesheets/cama/cama1.json');

					//puerta1
					this.load.spritesheet('puerta1', 'assets/spritesheets/puerta1/puerta1_changer.png', { frameWidth: 56, frameHeight: 101 });
					this.load.json('shapes_puerta1', 'assets/spritesheets/puerta1/puerta1.json');

					//puerta2
					this.load.spritesheet('puerta2', 'assets/spritesheets/puerta2/puerta2_changer.png', { frameWidth: 56, frameHeight: 101 });
					this.load.json('shapes_puerta2', 'assets/spritesheets/puerta2/puerta2.json');

					//puerta3
					this.load.spritesheet('puerta3', 'assets/spritesheets/puerta3/puerta3_changer.png', { frameWidth: 56, frameHeight: 101 });
					this.load.json('shapes_puerta3', 'assets/spritesheets/puerta3/puerta3.json');

					//puerta4
					this.load.spritesheet('puerta4', 'assets/spritesheets/puerta4/puerta4_changer.png', { frameWidth: 56, frameHeight: 103 });
					this.load.json('shapes_puerta4', 'assets/spritesheets/puerta4/puerta4.json');

					//puerta5
					this.load.spritesheet('puerta5', 'assets/spritesheets/puerta5/puerta5_changer.png', { frameWidth: 61, frameHeight: 109 });
					this.load.json('shapes_puerta5', 'assets/spritesheets/puerta5/puerta5.json');

					//estanteria llave cajon
					this.load.spritesheet('estanteriaLlaveCajon', 'assets/spritesheets/estanteriaLlaveCajon/estanteriaLlaveCajon_changer.png', { frameWidth: 68, frameHeight: 134 });
					this.load.json('shapes_estanteriaLlaveCajon', 'assets/spritesheets/estanteriaLlaveCajon/estanteriaLlaveCajon.json');
					
					//taburete
					this.load.spritesheet('taburete', 'assets/spritesheets/taburete/taburete.png', { frameWidth: 20, frameHeight: 25 });
					this.load.json('shapes_taburete', 'assets/spritesheets/taburete/taburete.json');

					//estanteria 
					this.load.spritesheet('estanteria', 'assets/spritesheets/estanteria/estanteria.png', { frameWidth: 68, frameHeight: 134 });
					this.load.json('shapes_estanteria', 'assets/spritesheets/estanteria/estanteria.json');


					//player_f
					this.load.spritesheet('player_f', 'assets/spritesheets/player_f/player_f_idel.png', { frameWidth: 32, frameHeight: 57 });
					this.load.json('shapes_player_f', 'assets/spritesheets/player_f/player_f.json');

					//nevera
					this.load.spritesheet('nevera', 'assets/spritesheets/nevera/nevera_changer.png', { frameWidth: 79, frameHeight: 103 });
					this.load.json('shapes_nevera', 'assets/spritesheets/nevera/nevera.json');
					//calabaza
					this.load.spritesheet('calabaza', 'assets/spritesheets/calabaza/calabaza_changer.png', { frameWidth: 20, frameHeight: 20 });
					this.load.json('shapes_calabaza', 'assets/spritesheets/calabaza/calabaza.json');

					//mesilla
					this.load.spritesheet('mesilla', 'assets/spritesheets/mesilla/mesilla_changer.png', { frameWidth: 49, frameHeight: 49 });
					this.load.json('shapes_mesilla', 'assets/spritesheets/mesilla/mesilla.json');

					this.load.spritesheet('armario','assets/spritesheets/armario/armario.png', {frameWidth: 106, frameHeight: 139});

					this.load.spritesheet('bolCebolla','assets/spritesheets/bolCebolla/bolCebolla.png', {frameWidth: 19, frameHeight: 19});

					this.load.spritesheet('platoJamon','assets/spritesheets/platoJamon/platoJamon.png', {frameWidth: 22, frameHeight: 21});

					this.load.spritesheet('retrete','assets/spritesheets/retrete/retrete.png', {frameWidth: 29, frameHeight: 39});

					this.load.spritesheet('taquilla','assets/spritesheets/taquilla/taquilla.png', {frameWidth: 79, frameHeight: 121});



					//inventarios
					this.load.image('inventario_h','assets/image/inventario_h.png');
					this.load.image('inventario_f','assets/image/inventario_f.png');

					//Cuadro texto
					this.load.image('cuadro_texto','assets/image/texto.png');

					//Action
					this.load.image('action','assets/image/action.png');
    },
    create: function() { 
	
				function xIso(xO,yO){
					var xI;
					var txO = (xO - yO) * tileWidthHalf;
					xI = centerX + txO;
					return xI;
				}
				
				function yIso(xO,yO){
					var yI;
					var tyO = (xO + yO) * tileHeightHalf;
					yI = centerY + tyO;
					return yI;
				}

				function dIso(xO,yO,l){
					var dI;
					var tyO = (xO + yO) * tileHeightHalf;
					dI = (centerY + tyO)+(tileHeightHalf*l);
					return dI+l;
				}

				function xOrt(xI,yI){
					var xO,yO;

					yO= (((-xI + centerX)/tileWidthHalf) + ((yI-centerY)/tileHeightHalf))/2;
					xO= (xI - centerX + (yO*tileWidthHalf))/tileWidthHalf;
					return xO;
				}
				function yOrt(xI,yI){
					var yO;

					yO= (((-xI + centerX)/tileWidthHalf) + ((yI-centerY)/tileHeightHalf))/2;
					return yO;
				}
				
				function obtenerValorEtiqueta(cadena, etiqueta){
					while(cadena.length > 0){
						let indice = cadena.indexOf(";");
						if(indice == -1){
							return '';
						}
						let extraida = cadena.substring(0, indice);
						cadena = cadena.substring(indice+1,cadena.length);
						indice = extraida.indexOf("=");
						if(indice == -1){
							return '';
						}
						var extraida2 = extraida.substring(0, indice);
						if(extraida2 == etiqueta){
							return extraida.substring(indice+1,extraida.length);
						}
					}
					return '';
				}

				// Muestra texto humano
				function printTextH(texto){
					if ((personaje == "humano") || (personaje == "local"))  {
						if (!(texto == '')) {
							text_cTh.setText(texto);
							cam5.visible = true;
						}
					}
				}

				// Muestra texto fantasma
				function printTextF(texto){
					if ((personaje == "fantasma") || (personaje == "local")) {
						if (!(texto == '')) {
							text_cTf.setText(texto);
							cam6.visible = true;
						}
					}
				}



				function selectItemH (x,y,list, index,scene){
					
					for(var i = 0; i< textListH.length; i++){	
						textListH[i].destroy();
					}
					var i = 0;
					list.forEach (function(value) {
						
						if(i == index){
							textListH[i] = scene.add.text(x, y + (i*18) + 2, value,{ fontSize: '18px',fill:'#fff', fontStyle: 'bold' });
					    }else{
					    	textListH[i] = scene.add.text(x, y + (i*18) + 2, value,{ fontSize: '18px',fill:'#000', fontStyle: 'bold' });
					    }
					    textListH[i].depth = 10;
						i++;
					});
					
				}

				function selectItemF (x,y,list, index,scene){
					
					for(var i = 0; i< textListF.length; i++){	
						textListF[i].destroy();
					}
					var i = 0;
					list.forEach (function(value) {
						
						if(i == index){
							textListF[i] = scene.add.text(x, y + (i*18) + 2, value,{ fontSize: '18px',fill:'#fff', fontStyle: 'bold' });
					    }else{
					    	textListF[i] = scene.add.text(x, y + (i*18) + 2, value,{ fontSize: '18px',fill:'#000', fontStyle: 'bold' });
					    }
					    textListF[i].depth = 10;
						i++;
					});
					
				}


				function createAction(name,x,y){
					var action = this.matter.add.image(xIso(x,y), yIso(x,y), 'action', 0, {
					                	isStatic: true,
					                	vertices:[{"x":0,"y":0}, 
					                                {"x":15,"y":7}, 
					                                {"x":30,"y":0}, 
					                                {"x":15,"y":-7}],
					                	})
					
					var category = obtenerValorEtiqueta(name,'categoria');
					action.depth = dIso(x,y,2);
					if(category == 5){    
				    action.setCollisionCategory(cat5);
					}
					if(category == 6){    
				    action.setCollisionCategory(cat6);
					}
					if(category == 7){    
				    action.setCollisionCategory(cat7);
					}
					action.name = name;
				    
				}

				function createImagen(name,x,y){

					var object = matter.add.image(xIso(x,y), yIso(x,y), obtenerValorEtiqueta(name,'sprite'), 0, {
						                		isStatic: false,
						                		vertices:[{"x":0,"y":0}, 
						                                  {"x":15,"y":7}, 
						                                  {"x":30,"y":0}, 
						                                  {"x":15,"y":-7}],
						                	});
					object.depth = dIso(xOrt(object.x,object.y),yOrt(object.x,object.y),2);
					if(obtenerValorEtiqueta(name,'estatico') == 'si'){
						object.setStatic(true);
					}
					var category = obtenerValorEtiqueta(name,'categoria');
					if(category == 2){
						object.setCollisionCategory(cat2);
						object.setCollidesWith([ cat1, cat2, cat4 ]);
					}
					if(category == 3){
						object.setCollisionCategory(cat3);
						object.setCollidesWith([ cat1, cat3, cat4 ]);
					}
					if(category == 4){
						object.setCollisionCategory(cat4);
						object.setCollidesWith([ cat1, cat2, cat3, cat4 ]);
					}

					if(category == 5){
						object.setCollisionCategory(cat5);
						object.setCollidesWith([ cat2 ]);
					}
					if(category == 6){
						object.setCollisionCategory(cat6);
						object.setCollidesWith([ cat3 ]);
					}
					if(category == 7){
						object.setCollisionCategory(cat7);
						object.setCollidesWith([ cat2, cat3 ]);
					}


					object.name = name;
					objetosMapa.add(object); 
				}

				function createSprite(name,x,y){
					var shapes_o = scene.cache.json.get('shapes_' + obtenerValorEtiqueta(name,'sprite'));
					var object = matter.add.sprite(xIso(x,y), yIso(x,y)+20, obtenerValorEtiqueta(name,'sprite'), 0, {shape: shapes_o.shape});

					var category = obtenerValorEtiqueta(name,'categoria');
					
					if(!(obtenerValorEtiqueta(name,'depth') == "")){
						object.depth = dIso(xOrt(object.x,object.y),yOrt(object.x,object.y),obtenerValorEtiqueta(name,'depth'));
					}else{
						object.depth = dIso(xOrt(object.x,object.y),yOrt(object.x,object.y),2);
					}	
					
					if(obtenerValorEtiqueta(name,'numeroSprite') == ""){
						object.setFrame(0);
					}else{
						object.setFrame(obtenerValorEtiqueta(name,'numeroSprite'));
					}

					object.name = name;
					objetosMapa.add(object); 

					if(obtenerValorEtiqueta(name,'animacion') == 'si'){
						object.anims.play(obtenerValorEtiqueta(name,'sprite'), true);
					}

					if(obtenerValorEtiqueta(name,'estatico') == 'si'){
						object.setStatic(true);
					}
					
					if(obtenerValorEtiqueta(name,'sprite') == 'player_h'){
						player_h = object;
						object.setCollisionCategory(cat2);
						object.setCollidesWith([ cat1, cat2, cat4, cat5, cat7 ]);
					}
					else if(obtenerValorEtiqueta(name,'sprite') == 'player_f'){
						player_f = object;
						object.setCollisionCategory(cat3);
						object.setCollidesWith([ cat1, cat3, cat4, cat6, cat7 ]);
					}else{
						if(category == 2){
							object.setCollisionCategory(cat2);
							object.setCollidesWith([ cat1, cat2, cat4 ]);
						}
						if(category == 3){
							object.setCollisionCategory(cat3);
							object.setCollidesWith([ cat1, cat3, cat4 ]);
						}
						if(category == 4){
							object.setCollisionCategory(cat4);
							object.setCollidesWith([ cat1, cat2, cat3, cat4 ]);
						}
						if(category == 5){
						object.setCollisionCategory(cat5);
						object.setCollidesWith([ cat2 ]);
						}
						if(category == 6){
							object.setCollisionCategory(cat6);
							object.setCollidesWith([ cat3 ]);
						}
						if(category == 7){
							object.setCollisionCategory(cat7);
							object.setCollidesWith([ cat2, cat3 ]);
						}
					}
						
				}
				
		//  Input Events
				    cursors = this.input.keyboard.createCursorKeys();

				    //Animaciones
				    this.anims.create({
				        key: 'player_h',
				        frames: this.anims.generateFrameNumbers('player_h', { start: 0, end: 9 }),
				        frameRate: 10,
				        repeat: -1
				    });
				    this.anims.create({
				        key: 'player_f',
				        frames: this.anims.generateFrameNumbers('player_f', { start: 0, end: 8 }),
				        frameRate: 10,
				        repeat: -1
				    });



					//  Parse the data out of the map
				        
				    var layer;
				    var tile;
				    matter = this.matter;
				    scene = this;
				    cat1 = this.matter.world.nextCategory();
				    cat2 = this.matter.world.nextCategory();
				    cat3 = this.matter.world.nextCategory();
				    cat4 = this.matter.world.nextCategory();
				    cat5 = this.matter.world.nextCategory();
				    cat6 = this.matter.world.nextCategory();
				    cat7 = this.matter.world.nextCategory();

				    //Informaci�n del mapa 
					data = this.cache.json.get('map');
				    tilewidth = data.tilewidth;
					tileheight = data.tileheight;
					tileWidthHalf = tilewidth / 2;
					tileHeightHalf = tileheight / 2;
					numTilesLayers = data.layers[0].layers.length;
					numFolders = data.layers.length;

					var posLayerActionsH = [];
					var posLayerImageH = [];
					var posLayerSpriteH = [];
					var posLayerActionsF,posLayerImageF, posLayerSpriteF;
					var posLayerActionsB,posLayerImageB, posLayerSpriteB;
					
					for(var j = 0; j < numFolders; j++){
						numLayers = data.layers[j].layers.length;
						for(var i = 0; i < numLayers; i++){
							if(data.layers[j].layers[i].name == "actionsHumano"){
								posLayerActionsH = [j,i];
							}
							if(data.layers[j].layers[i].name == "actionsFantasma"){
								posLayerActionsF = [j,i];
							}
							if(data.layers[j].layers[i].name == "createImageHumano"){
								posLayerImageH = [j,i];
							}
							if(data.layers[j].layers[i].name == "createImageFantasma"){
								posLayerImageF = [j,i];
							}
							if(data.layers[j].layers[i].name == "createSpritesHumano"){
								posLayerSpriteH = [j,i];
							}
							if(data.layers[j].layers[i].name == "createSpritesFantasma"){
								posLayerSpriteF = [j,i];
							}
							if(data.layers[j].layers[i].name == "actionsBoth"){
								posLayerActionsB = [j,i];
							}
							if(data.layers[j].layers[i].name == "createImageBoth"){
								posLayerImageB = [j,i];
							}
							if(data.layers[j].layers[i].name == "createSpritesBoth"){
								posLayerSpriteB = [j,i];
							}
						}
					}

					var actionsLayerH = data.layers[posLayerActionsH[0]].layers[posLayerActionsH[1]].objects;
					var createImageLayerH = data.layers[posLayerImageH[0]].layers[posLayerImageH[1]].objects;
					var createSpriteLayerH = data.layers[posLayerSpriteH[0]].layers[posLayerSpriteH[1]].objects;

					var actionsLayerF = data.layers[posLayerActionsF[0]].layers[posLayerActionsF[1]].objects;
					var createImageLayerF = data.layers[posLayerImageF[0]].layers[posLayerImageF[1]].objects;
					var createSpriteLayerF = data.layers[posLayerSpriteF[0]].layers[posLayerSpriteF[1]].objects;
					
					var actionsLayerB = data.layers[posLayerActionsB[0]].layers[posLayerActionsB[1]].objects;
					var createImageLayerB = data.layers[posLayerImageB[0]].layers[posLayerImageB[1]].objects;
					var createSpriteLayerB = data.layers[posLayerSpriteB[0]].layers[posLayerSpriteB[1]].objects;

					//Los tama�os de todas las capas del mapa tienen que ser iguales 
					mapwidth = data.layers[0].layers[0].width;
					mapheight = data.layers[0].layers[0].height;

					centerX = mapwidth * tileWidthHalf;
					centerY = mapheight * tileHeightHalf;
						

				    for(var l = 0; l<numTilesLayers; l++){

				        layer = data.layers[0].layers[l].data;
				        	
					    let i = 0;
					    for (let y = 0; y < mapheight; y++)
					    {
					        for (let x = 0; x < mapwidth; x++)
					        {
					          	const id = layer[i] - 1;
					            if(id != -1){
					                tile = this.matter.add.image(xIso(x,y), yIso(x,y), 'tiles', id, {
					                	isStatic: true,
					                	vertices:[{"x":0,"y":0}, 
					                                {"x":15,"y":7}, 
					                                {"x":30,"y":0}, 
					                                {"x":15,"y":-7}],
					                	})
					                if(l < 2 ){
					                	if(id == 0 || id == 1){
					                		tile.setCollisionCategory(cat1);
					                	}
					                	if(id ==2 || id == 10){
					                		tile.setCollisionCategory(cat1);
					                	}
					                	if(id == 11 || id ==12){
					                		tile.setCollisionCategory(cat1);
					                	}
					                	if(id ==22 || id == 23){
					                		tile.setCollisionCategory(cat1);
					                	}
					                }

					                tile.setStatic(true);
					                tile.name = "x=" + x+";y=" + y+ ";";

					            tile.depth = dIso(x,y,l*2);
					            }

					            i++;

					        }
					    }
				    }

				//incluye acciones Humano
					
				    for (o = 0; o < actionsLayerH.length; o++){
					    var action_x = (actionsLayerH[o].x / tileheight);
					    var action_y = (actionsLayerH[o].y / tileheight);
					    var cad = actionsLayerH[o].name + 'categoria=5;';
					    createAction(cad,action_x,action_y); 
					}

					for (o = 0; o < actionsLayerF.length; o++){
					    var action_x = (actionsLayerF[o].x / tileheight);
					    var action_y = (actionsLayerF[o].y / tileheight);
					    var cad = actionsLayerF[o].name + 'categoria=6;';
					    createAction(cad,action_x,action_y); 
					}

					for (o = 0; o < actionsLayerB.length; o++){
					    var action_x = (actionsLayerB[o].x / tileheight);
					    var action_y = (actionsLayerB[o].y / tileheight);
					    var cad = actionsLayerB[o].name + 'categoria=7;';
					    createAction(cad,action_x,action_y); 
					}

				    //Humano
				    //crear imagenes
				    for (o = 0; o < createImageLayerH.length; o++){
					    var object_x = (createImageLayerH[o].x / tileheight);
					    var object_y = (createImageLayerH[o].y / tileheight);
					    var cad = createImageLayerH[o].name + 'categoria=2;';
					    createImagen(cad,object_x,object_y,2);

					}
					//crear sprites
					for (o = 0; o < createSpriteLayerH.length; o++){
					    var object_x = (createSpriteLayerH[o].x / tileheight);
					    var object_y = (createSpriteLayerH[o].y / tileheight);
					    var cad = createSpriteLayerH[o].name + 'categoria=2;';
					    createSprite(cad,object_x,object_y,2);
					}

					//Fantasma
					//crear imagenes
				    for (o = 0; o < createImageLayerF.length; o++){
					    var object_x = (createImageLayerF[o].x / tileheight);
					    var object_y = (createImageLayerF[o].y / tileheight);
					    var cad = createImageLayerF[o].name + 'categoria=3;';
					    createImagen(cad,object_x,object_y,3);

					}
					//crear sprites
					for (o = 0; o < createSpriteLayerF.length; o++){
					    var object_x = (createSpriteLayerF[o].x / tileheight);
					    var object_y = (createSpriteLayerF[o].y / tileheight);
					    var cad = createSpriteLayerF[o].name + 'categoria=3;';
					    createSprite(cad,object_x,object_y,3);
					}

					//Ambos
					//crear imagenes
				    for (o = 0; o < createImageLayerB.length; o++){
					    var object_x = (createImageLayerB[o].x / tileheight);
					    var object_y = (createImageLayerB[o].y / tileheight);
					    var cad = createImageLayerB[o].name + 'categoria=4;';
					    createImagen(cad,object_x,object_y,4);

					}
					//crear sprites
					for (o = 0; o < createSpriteLayerB.length; o++){
					    var object_x = (createSpriteLayerB[o].x / tileheight);
					    var object_y = (createSpriteLayerB[o].y / tileheight);
					    var cad = createSpriteLayerB[o].name + 'categoria=4;';
					    createSprite(cad,object_x,object_y,4);
					}
					
					//Inventario fantasma
				    this.matter.add.sprite(440, 0, 'inventario_f', 0,{isStatic: true}).setOrigin(0,0);
				    //Inventario humano
				    this.matter.add.sprite(0, 0, 'inventario_h', 0,{isStatic: true}).setOrigin(0,0);

				    //Camaras				    
				    
				    if (personaje == 'local'){
				    
					    // Humano
					   
					    this.cameras.main.setSize(440, 320);
					    this.cameras.main.startFollow(player_h);
					    //Camara inventario humano
						cam3 = this.cameras.add(0,0, 200, 200);
						cam3.setViewport(0, 0, 200, 200);	//Donde queremos que salga la camara en el navegador y el tama�o del viewport
						cam3.setAlpha(0.85);
						cam3.visible = false;
						//Camara texto humano
						cam5 = this.cameras.add(0,281, 440, 39);
						cam5.centerOn(220, 300); 
						cam5.setAlpha(0.85);
						cam5.visible = false;
						//Cuadro de Texto
					    text_cTh = this.matter.add.image(0, 281, 'cuadro_texto', 0,{isStatic: true}).setOrigin(0,0);
					    text_cTh = scene.add.text(7, 281, "",{ fontSize: '12px',fill:'#000', fontStyle: 'bold' });
					    text_cTh.setWordWrapWidth(430,true);			    
					        
					    // Fantasma
					    
					    cam2 = this.cameras.add(440, 0, 440, 320);
					    cam2.startFollow(player_f, false, 0.5, 0.5);
					    //Camara inventario fantasma
						cam4 = this.cameras.add(440,0, 200, 200);
						cam4.setViewport(440, 0, 200, 200);	//Donde queremos que salga la camara en el navegador y el tama�o del viewport
						cam4.centerOn(540, 100); //En punto del escenario donde esta centrado el objetivo de la c�mara
						cam4.setAlpha(0.85);
						cam4.visible = false;
						//Camara texto fantasma
						cam6 = this.cameras.add(440,281, 440, 39);
						cam6.centerOn(660, 300); 
						cam6.setAlpha(0.85);
						cam6.visible = false;
						//Cuadro de Texto
					    text_cTf = this.matter.add.image(440, 281, 'cuadro_texto', 0,{isStatic: true}).setOrigin(0,0);
					    text_cTf = scene.add.text(447, 281, "",{ fontSize: '12px',fill:'#000', fontStyle: 'bold' });
					    text_cTf.setWordWrapWidth(430,true);				    
				    } else {
										
						// Humano
					   
					    this.cameras.main.setSize(440, 320);
					    this.cameras.main.setViewport(220, 0, 440, 320);
					    this.cameras.main.startFollow(player_h);
					    //Camara inventario humano
						cam3 = this.cameras.add(0,0, 200, 200);
						cam3.setViewport(0, 0, 200, 200);	//Donde queremos que salga la camara en el navegador y el tama�o del viewport
						cam3.setAlpha(0.85);
						cam3.visible = false;
						//Camara texto humano
						cam5 = this.cameras.add(0,281, 440, 160);
						cam5.centerOn(220, 300); 
						cam5.setAlpha(0.85);
						cam5.visible = false;
						//Cuadro de Texto
					    text_cTh = this.matter.add.image(0, 281, 'cuadro_texto', 0,{isStatic: true}).setOrigin(0,0);
					    text_cTh = scene.add.text(7, 285, "",{ fontSize: '12px',fill:'#000', fontStyle: 'bold' });
					    text_cTh.setWordWrapWidth(430,true);	
					    
						
						// Fantasma
					    
					    cam2 = this.cameras.add(0,0, 440, 320);
					    cam2.setViewport(220, 0, 440, 320);
					    cam2.startFollow(player_f, false, 0.5, 0.5);
					    //Camara inventario fantasma
						cam4 = this.cameras.add(440,0, 200, 200);
						cam4.setViewport(440, 0, 200, 200);	//Donde queremos que salga la camara en el navegador y el tama�o del viewport
						cam4.centerOn(540, 100); //En punto del escenario donde esta centrado el objetivo de la c�mara
						cam4.setAlpha(0.85);
						cam4.visible = false;
						//Camara texto fantasma
						cam6 = this.cameras.add(0,281, 440, 160);
						cam6.centerOn(660, 300); 
						cam6.setAlpha(0.85);
						cam6.visible = false;
						//Cuadro de Texto
					    text_cTf = this.matter.add.image(440, 281, 'cuadro_texto', 0,{isStatic: true}).setOrigin(0,0);
					    text_cTf = scene.add.text(447, 285, "",{ fontSize: '12px',fill:'#000', fontStyle: 'bold' });
					    text_cTf.setWordWrapWidth(430,true);
					    
						if (personaje == 'fantasma'){    					
							this.cameras.main.visible = false;
						    cam3.visible = false;
						    cam5.visible = false;
						}
						
						if (personaje == 'humano'){	
							cam2.visible = false;
						    cam4.visible = false;
						    cam6.visible = false;
						}
					}				

				function colisionHumano(humano,objectoAuxiliar){
						if(!(obtenerValorEtiqueta(humano.name,'nombre') === 'fantasma')){
							
							var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'textoH');
							if(!(texto == "")){
								printTextH(texto);
							}
							var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'textoF');
							if(!(texto == "")){
								printTextF(texto);
							}
							var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'textoB');
							if(!(texto == "")){
								printTextH(texto);
								printTextF(texto);
							}
							
							var accion = obtenerValorEtiqueta(objectoAuxiliar.name,'accion');
							if(accion == "tp"){
								
								var coordenadasX = parseFloat (obtenerValorEtiqueta(objectoAuxiliar.name,'tpX'));
								var coordenadasY = parseFloat (obtenerValorEtiqueta(objectoAuxiliar.name,'tpY'));
								var condicionString = obtenerValorEtiqueta(objectoAuxiliar.name,'condicion');

								cam5.visible = false;
								
								if(condicionString == ""){
									player_h.x = xIso(coordenadasX,coordenadasY);
								    player_h.y = yIso(coordenadasX,coordenadasY);
								}else{
								    var condicionArray =  JSON.parse(condicionString);
								    var condicionConjunto = new Set (condicionArray);
								        		
								    var interseccion = new Set ([...inventario1H].filter(x => condicionConjunto.has(x)));

								    if(interseccion.size == condicionConjunto.size){
								        player_h.x = xIso(coordenadasX,coordenadasY);
								        player_h.y = yIso(coordenadasX,coordenadasY);
								    }
								}
								
							}
							if(accion == "coger"){
								console.log(inventarioH.size);
								if (inventarioH.size < 5) {
								    inventarioH.add(objectoAuxiliar.name);
								    objetosMapa.forEach (function(value) {
									    if(value.name == objectoAuxiliar.name){
										    objetosMapa.delete(value);
									    }
									});
									objectoAuxiliar.destroy();
								
									var inventarioArray;
									inventarioH.forEach (function() {
									    inventarioArray =  obtenerValorEtiqueta(objectoAuxiliar.name,'nombre');
										inventario1H.add(inventarioArray);
									});
									selectItemH(5,40,inventario1H,indexInventarioH,scene);
								}
							}

							if(accion == "drooperI"){
								var caracteristicas = objectoAuxiliar.name;
								
								objetosMapa.forEach (function(value) {
								    if(value.name == objectoAuxiliar.name){
									    objetosMapa.delete(value);
								    }
								});
								objectoAuxiliar.destroy(); 
								
								var droopAccion = obtenerValorEtiqueta(caracteristicas,'droopAccion');
								var droopSprite = obtenerValorEtiqueta(caracteristicas,'droopSprite');
								var droopName = obtenerValorEtiqueta(caracteristicas,'droopName');
								var droopX = obtenerValorEtiqueta(caracteristicas,'droopX');
								var droopY = obtenerValorEtiqueta(caracteristicas,'droopY');
								var droopCategoria = obtenerValorEtiqueta(caracteristicas,'droopCategoria');
								var droopCondicion = obtenerValorEtiqueta(caracteristicas,'droopCondicion');
								var droopTextoH = obtenerValorEtiqueta(caracteristicas,'droopTextoH');
								var droopTextoF = obtenerValorEtiqueta(caracteristicas,'droopTextoF');
								var droopTextoB = obtenerValorEtiqueta(caracteristicas,'droopTextoB');
								
								cadena = 'accion='+ droopAccion +';sprite='+ droopSprite + ';nombre='+ droopName +";x=" + droopX +";y=" + droopY + ";categoria=" + droopCategoria + ';condicion=' + droopCondicion +';textoH=' + droopTextoH +';textoF='+ droopTextoF +';textoB='+ droopTextoB +';';

								var coordenadaX = parseFloat (obtenerValorEtiqueta(cadena,'x'));
								var coordenadaY = parseFloat (obtenerValorEtiqueta(cadena,'y'));
								createImagen(cadena,coordenadaX,coordenadaY);
							}
							if(accion == "changer"){
								var condicionString = obtenerValorEtiqueta(objectoAuxiliar.name,'condicion');		
								if(condicionString == ""){
									var realizar = true;
								}else{
								    var condicionArray =  JSON.parse(condicionString);
								    var condicionConjunto = new Set (condicionArray);			        		
								    var interseccion = new Set ([...inventario1H].filter(x => condicionConjunto.has(x)));
								    if(interseccion.size == condicionConjunto.size){
								        var realizar = true;
								    }
								}

								var caracteristicas = objectoAuxiliar.name;

								if (realizar == true){
									var numFrames = objectoAuxiliar.frame.glTexture.width/objectoAuxiliar.frame.data.sourceSize.w;
									var frameIdx = objectoAuxiliar.frame.name;
									if(frameIdx==numFrames-2){
										objectoAuxiliar.setFrame(numFrames-1);
									var droopAccion = obtenerValorEtiqueta(caracteristicas,'droopAccion');
									var droopSprite = obtenerValorEtiqueta(caracteristicas,'droopSprite');
									var droopName = obtenerValorEtiqueta(caracteristicas,'droopName');
									var droopX = obtenerValorEtiqueta(caracteristicas,'droopX');
									var droopY = obtenerValorEtiqueta(caracteristicas,'droopY');
									var droopCategoria = obtenerValorEtiqueta(caracteristicas,'droopCategoria');
									var droopCondicion = obtenerValorEtiqueta(caracteristicas,'droopCondicion');
									var droopTextoH = obtenerValorEtiqueta(caracteristicas,'droopTextoH');
									var droopTextoF = obtenerValorEtiqueta(caracteristicas,'droopTextoF');
									var droopTextoB = obtenerValorEtiqueta(caracteristicas,'droopTextoB');
									
									cadena = 'accion='+ droopAccion +';sprite='+ droopSprite + ';nombre='+ droopName +";x=" + droopX +";y=" + droopY + ";categoria=" + droopCategoria + ';condicion=' + droopCondicion +';textoH=' + droopTextoH +';textoF='+ droopTextoF +';textoB='+ droopTextoB +';';

									var coordenadaX = parseFloat (obtenerValorEtiqueta(cadena,'x'));
									var coordenadaY = parseFloat (obtenerValorEtiqueta(cadena,'y'));
									createImagen(cadena,coordenadaX,coordenadaY);

									var texto = obtenerValorEtiqueta(caracteristicas,'changerTextoH');
									if(!(texto == "")){
										printTextH(texto);
									}
									var texto = obtenerValorEtiqueta(caracteristicas,'changerTextoF');
									if(!(texto == "")){
										printTextF(texto);
									}
									var texto = obtenerValorEtiqueta(caracteristicas,'changerTextoB');
									if(!(texto == "")){
										printTextH(texto);
										printTextF(texto);
									}
								

									}else{
										objectoAuxiliar.setFrame(frameIdx++);
									}
								}else{

										var texto = obtenerValorEtiqueta(caracteristicas,'humanoTextoH');
										if(!(texto == "")){
											printTextH(texto);
										}
										var texto = obtenerValorEtiqueta(caracteristicas,'humanoTextoF');
										if(!(texto == "")){
											printTextF(texto);
										}
										var texto = obtenerValorEtiqueta(caracteristicas,'humanoTextoB');
										if(!(texto == "")){
											printTextH(texto);
											printTextF(texto);
										}
										var texto = obtenerValorEtiqueta(caracteristicas,'fantasmaTextoH');
										if(!(texto == "")){
											printTextH(texto);
										}
										var texto = obtenerValorEtiqueta(caracteristicas,'fantasmahumanoTextoF');
										if(!(texto == "")){
											printTextF(texto);
										}
										var texto = obtenerValorEtiqueta(caracteristicas,'fantasmahumanoTextoB');
										if(!(texto == "")){
											printTextH(texto);
											printTextF(texto);
										}		
								}
							}
							if(accion == "changer-tp"){
								
								var condicion = false;
								var hecho = false;
								var condicionString = obtenerValorEtiqueta(objectoAuxiliar.name,'condicion');		
								if(condicionString == ""){
									var condicion = true;
								}else{
								    var condicionArray =  JSON.parse(condicionString);
								    var condicionConjunto = new Set (condicionArray);			        		
								    var interseccion = new Set ([...inventario1H].filter(x => condicionConjunto.has(x)));
								    if(interseccion.size == condicionConjunto.size){
								        var condicion = true;
								    }
								}

								var numFrames = objectoAuxiliar.frame.glTexture.width/objectoAuxiliar.frame.data.sourceSize.w;
								var frameIdx = objectoAuxiliar.frame.name;

								if((frameIdx==numFrames-1) || (obtenerValorEtiqueta(objectoAuxiliar.name,'pasoHumano') == 'si')) {

										var coordenadasX = parseFloat (obtenerValorEtiqueta(objectoAuxiliar.name,'tpX'));
										var coordenadasY = parseFloat (obtenerValorEtiqueta(objectoAuxiliar.name,'tpY'));

										cam5.visible = false;
										
										player_h.x = xIso(coordenadasX,coordenadasY);
										player_h.y = yIso(coordenadasX,coordenadasY);

										hecho = true;
								}

								if (condicion == true){

									var caracteristicas = objectoAuxiliar.name;
									if(frameIdx==numFrames-2){
										objectoAuxiliar.setFrame(numFrames-1);

										var coordenadasX = parseFloat (obtenerValorEtiqueta(objectoAuxiliar.name,'tpX'));
										var coordenadasY = parseFloat (obtenerValorEtiqueta(objectoAuxiliar.name,'tpY'));

										cam5.visible = false;
										
										player_h.x = xIso(coordenadasX,coordenadasY);
										player_h.y = yIso(coordenadasX,coordenadasY);
															
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'changerTextoH');
										if(!(texto == "")){
											printTextH(texto);
										}
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'changerTextoF');
										if(!(texto == "")){
											printTextF(texto);
										}
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'changerTextoB');
										if(!(texto == "")){
											printTextH(texto);
											printTextF(texto);
										}
										hecho = true;
										realizar = false;				

									}else{
										objectoAuxiliar.setFrame(frameIdx++);
									}
								}


								if (hecho == false){
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'humanoTextoH');
										if(!(texto == "")){
											printTextH(texto);
										}
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'humanoTextoF');
										if(!(texto == "")){
											printTextF(texto);
										}
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'humanoTextoB');
										if(!(texto == "")){
											printTextH(texto);
											printTextF(texto);
										}
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'fantasmaTextoH');
										if(!(texto == "")){
											printTextH(texto);
										}
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'fantasmahumanoTextoF');
										if(!(texto == "")){
											printTextF(texto);
										}
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'fantasmahumanoTextoB');
										if(!(texto == "")){
											printTextH(texto);
											printTextF(texto);
										}

								}
							}
						}
						
					}
					
					function colisionFantasma(fantasma,objectoAuxiliar){
					
						if(!(obtenerValorEtiqueta(fantasma.name,'nombre') === 'humano')){
							var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'textoH');
							if(!(texto == "")){
								printTextH(texto);
							}
							var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'textoF');
							if(!(texto == "")){
								printTextF(texto);
							}
							var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'textoB');
							if(!(texto == "")){
								printTextH(texto);
								printTextF(texto);
							}

							var accion =  obtenerValorEtiqueta(objectoAuxiliar.name,'accion');
							if(accion == "tp"){

								var coordenadasX = parseFloat (obtenerValorEtiqueta(objectoAuxiliar.name,'tpX'));
								var coordenadasY = parseFloat (obtenerValorEtiqueta(objectoAuxiliar.name,'tpY'));

								var condicionString = obtenerValorEtiqueta(objectoAuxiliar.name,'condicion');

								cam6.visible = false;
								
								if(condicionString == ""){
									player_f.x = xIso(coordenadasX,coordenadasY);
								    player_f.y = yIso(coordenadasX,coordenadasY);
								}else{
								    var condicionArray =  JSON.parse(condicionString);
								    var condicionConjunto = new Set (condicionArray);
								        		
								    var interseccion = new Set ([...inventario1H].filter(x => condicionConjunto.has(x)));

								    if(interseccion.size == condicionConjunto.size){
								        player_f.x = xIso(coordenadasX,coordenadasY);
								        player_f.y = yIso(coordenadasX,coordenadasY);
								    }
								}
							}
							if(accion == "coger"){
								if (inventarioF.size < 5) {
								    inventarioF.add(objectoAuxiliar.name);
								    objetosMapa.forEach (function(value) {
									    if(value.name == objectoAuxiliar.name){
										    objetosMapa.delete(value);
									    }
									});
									objectoAuxiliar.destroy();
								
									var inventarioArray;
									inventarioF.forEach (function() {
									    inventarioArray =  obtenerValorEtiqueta(objectoAuxiliar.name,'nombre');
										inventario1F.add(inventarioArray);
									});
									selectItemF(445,40,inventario1F,indexInventarioF,scene);
								}

							}
							if(accion == "drooperI"){
								var caracteristicas = objectoAuxiliar.name;
								
								objetosMapa.forEach (function(value) {
								    if(value.name == objectoAuxiliar.name){
									    objetosMapa.delete(value);
								    }
								});
								objectoAuxiliar.destroy(); 
								
								var droopAccion = obtenerValorEtiqueta(caracteristicas,'droopAccion');
								var droopSprite = obtenerValorEtiqueta(caracteristicas,'droopSprite');
								var droopName = obtenerValorEtiqueta(caracteristicas,'droopName');
								var droopX = obtenerValorEtiqueta(caracteristicas,'droopX');
								var droopY = obtenerValorEtiqueta(caracteristicas,'droopY');
								var droopCategoria = obtenerValorEtiqueta(caracteristicas,'droopCategoria');
								var droopCondicion = obtenerValorEtiqueta(caracteristicas,'droopCondicion');
								var droopTextoH = obtenerValorEtiqueta(caracteristicas,'droopTextoH');
								var droopTextoF = obtenerValorEtiqueta(caracteristicas,'droopTextoF');
								var droopTextoB = obtenerValorEtiqueta(caracteristicas,'droopTextoB');
								var tpX = obtenerValorEtiqueta(caracteristicas,'tpX');
								var tpY = obtenerValorEtiqueta(caracteristicas,'tpY');
								
								cadena = 'accion='+ droopAccion +';sprite='+ droopSprite + ';nombre='+ droopName +";x=" + droopX +";y=" + droopY + ";categoria=" + droopCategoria + ';condicion=' + droopCondicion +';textoH=' + droopTextoH +';textoF='+ droopTextoF +';textoB='+ droopTextoB +';tpX='+tpX + ";tpY=" + tpY + ";";
								var coordenadaX = parseFloat (obtenerValorEtiqueta(cadena,'x'));
								var coordenadaY = parseFloat (obtenerValorEtiqueta(cadena,'y'));
								createImagen(cadena,coordenadaX,coordenadaY);
							}
							if(accion == "changer"){
								var realizar = false;
								var condicionString = obtenerValorEtiqueta(objectoAuxiliar.name,'condicion');		
								if(condicionString == ""){
									var realizar = true;
								}else{
								    var condicionArray =  JSON.parse(condicionString);
								    var condicionConjunto = new Set (condicionArray);			        		
								    var interseccion = new Set ([...inventario1F].filter(x => condicionConjunto.has(x)));
								    if(interseccion.size == condicionConjunto.size){
								        var realizar = true;
								    }
								}


								var caracteristicas = objectoAuxiliar.name;

								if (realizar == true){
									var numFrames = objectoAuxiliar.frame.glTexture.width/objectoAuxiliar.frame.data.sourceSize.w;
									var frameIdx = objectoAuxiliar.frame.name;
									if(frameIdx==numFrames-2){
										objectoAuxiliar.setFrame(numFrames-1);
									var droopAccion = obtenerValorEtiqueta(caracteristicas,'droopAccion');
									var droopSprite = obtenerValorEtiqueta(caracteristicas,'droopSprite');
									var droopName = obtenerValorEtiqueta(caracteristicas,'droopName');
									var droopX = obtenerValorEtiqueta(caracteristicas,'droopX');
									var droopY = obtenerValorEtiqueta(caracteristicas,'droopY');
									var droopCategoria = obtenerValorEtiqueta(caracteristicas,'droopCategoria');
									var droopCondicion = obtenerValorEtiqueta(caracteristicas,'droopCondicion');
									var droopTextoH = obtenerValorEtiqueta(caracteristicas,'droopTextoH');
									var droopTextoF = obtenerValorEtiqueta(caracteristicas,'droopTextoF');
									var droopTextoB = obtenerValorEtiqueta(caracteristicas,'droopTextoB');
									var droopEstatico = obtenerValorEtiqueta(caracteristicas,'droopEstatico');
									var tpX = obtenerValorEtiqueta(caracteristicas,'tpX');
									var tpY = obtenerValorEtiqueta(caracteristicas,'tpY');
									
									cadena = 'accion='+ droopAccion +';sprite='+ droopSprite + ';nombre='+ droopName +";x=" + droopX +";y=" + droopY + ";categoria=" + droopCategoria + ';condicion=' + droopCondicion +';textoH=' + droopTextoH +';textoF='+ droopTextoF +';textoB='+ droopTextoB +';tpX='+tpX + ";tpY=" + tpY + ";estatico=" + droopEstatico + ";";

									var coordenadaX = parseFloat (obtenerValorEtiqueta(cadena,'x'));
									var coordenadaY = parseFloat (obtenerValorEtiqueta(cadena,'y'));
									createImagen(cadena,coordenadaX,coordenadaY);

									var texto = obtenerValorEtiqueta(caracteristicas,'changerTextoH');
									if(!(texto == "")){
										printTextH(texto);
									}
									var texto = obtenerValorEtiqueta(caracteristicas,'changerTextoF');
									if(!(texto == "")){
										printTextF(texto);
									}
									var texto = obtenerValorEtiqueta(caracteristicas,'changerTextoB');
									if(!(texto == "")){
										printTextH(texto);
										printTextF(texto);
									}
								

									}else{
										objectoAuxiliar.setFrame(frameIdx++);
									}
								}else{

										var texto = obtenerValorEtiqueta(caracteristicas,'humanoTextoH');
										if(!(texto == "")){
											printTextH(texto);
										}
										var texto = obtenerValorEtiqueta(caracteristicas,'humanoTextoF');
										if(!(texto == "")){
											printTextF(texto);
										}
										var texto = obtenerValorEtiqueta(caracteristicas,'humanoTextoB');
										if(!(texto == "")){
											printTextH(texto);
											printTextF(texto);
										}
										var texto = obtenerValorEtiqueta(caracteristicas,'fantasmaTextoH');
										if(!(texto == "")){
											printTextH(texto);
										}
										var texto = obtenerValorEtiqueta(caracteristicas,'fantasmahumanoTextoF');
										if(!(texto == "")){
											printTextF(texto);
										}
										var texto = obtenerValorEtiqueta(caracteristicas,'fantasmahumanoTextoB');
										if(!(texto == "")){
											printTextH(texto);
											printTextF(texto);
										}		
								}
							}
							if(accion == "changer-tp"){

								var condicion = false;
								var hecho = false;
								var condicionString = obtenerValorEtiqueta(objectoAuxiliar.name,'condicion');		
								if(condicionString == ""){
									var condicion = true;
								}else{
								    var condicionArray =  JSON.parse(condicionString);
								    var condicionConjunto = new Set (condicionArray);			        		
								    var interseccion = new Set ([...inventario1F].filter(x => condicionConjunto.has(x)));
								    if(interseccion.size == condicionConjunto.size){
								        var condicion = true;
								    }
								}

								
								var numFrames = objectoAuxiliar.frame.glTexture.width/objectoAuxiliar.frame.data.sourceSize.w;
								var frameIdx = objectoAuxiliar.frame.name;

								if((frameIdx==numFrames-1) || (obtenerValorEtiqueta(objectoAuxiliar.name,'pasoFantasma') == 'si')){
										var coordenadasX = parseFloat (obtenerValorEtiqueta(objectoAuxiliar.name,'tpX'));
										var coordenadasY = parseFloat (obtenerValorEtiqueta(objectoAuxiliar.name,'tpY'));

										cam6.visible = false;
										
										player_f.x = xIso(coordenadasX,coordenadasY);
										player_f.y = yIso(coordenadasX,coordenadasY);

										hecho = true;
								}

								if (condicion == true){
									var caracteristicas = objectoAuxiliar.name;
									if(frameIdx==numFrames-2){
										objectoAuxiliar.setFrame(numFrames-1);

										var coordenadasX = parseFloat (obtenerValorEtiqueta(objectoAuxiliar.name,'tpX'));
										var coordenadasY = parseFloat (obtenerValorEtiqueta(objectoAuxiliar.name,'tpY'));

										cam5.visible = false;
										
										player_f.x = xIso(coordenadasX,coordenadasY);
										player_f.y = yIso(coordenadasX,coordenadasY);
															
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'changerTextoH');
										if(!(texto == "")){
											printTextH(texto);
										}
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'changerTextoF');
										if(!(texto == "")){
											printTextF(texto);
										}
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'changerTextoB');
										if(!(texto == "")){
											printTextH(texto);
											printTextF(texto);
										}
										hecho = true;			

									}else{
										objectoAuxiliar.setFrame(frameIdx++);
									}
								}

								if (hecho == false){
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'humanoTextoH');
										if(!(texto == "")){
											printTextH(texto);
										}
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'humanoTextoF');
										if(!(texto == "")){
											printTextF(texto);
										}
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'humanoTextoB');
										if(!(texto == "")){
											printTextH(texto);
											printTextF(texto);
										}
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'fantasmaTextoH');
										if(!(texto == "")){
											printTextH(texto);
										}
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'fantasmahumanoTextoF');
										if(!(texto == "")){
											printTextF(texto);
										}
										var texto = obtenerValorEtiqueta(objectoAuxiliar.name,'fantasmahumanoTextoB');
										if(!(texto == "")){
											printTextH(texto);
											printTextF(texto);
										}

								}

							}
						}	
					}
					

					//Colisiones
				    this.matter.world.on('collisionstart', function (event) {
					    var objetoA = event.pairs[0].bodyA.gameObject;
					    var objetoB = event.pairs[0].bodyB.gameObject;
					    
					    if(obtenerValorEtiqueta(objetoA.name,'nombre') === 'humano'){
					    	colisionHumano(objetoA,objetoB);
					    }
					    if(obtenerValorEtiqueta(objetoA.name,'nombre') === 'fantasma'){
					    	colisionFantasma(objetoA,objetoB);
					    }
					    if(obtenerValorEtiqueta(objetoB.name,'nombre') === 'humano'){
					    	colisionHumano(objetoB,objetoA);
					    }
					    if(obtenerValorEtiqueta(objetoB.name,'nombre') === 'fantasma'){
					    	colisionFantasma(objetoB,objetoA);
					    }
				    });


				   	//Teclado Humano
				   	
				   	//Sacar inventario Q
					this.input.keyboard.on('keyup', function (event) {
				        if ((event.keyCode === 113 || event.keyCode === 81) && (personaje == 'humano' || personaje == "local"))
				        {
					       if (personaje == 'humano') {
								var message = JSON.stringify({'Tipo' : 'datos' , 'Subtipo' : 'Inventario', 'indexInventarioOnline' : indexInventarioH });
								connection.send(message);
							}
				            var i = 0;
				            var inventarioArray;
				            inventarioH.forEach (function(value) {
					        	if(i == indexInventarioH){
						        	inventarioArray =  value;
					        	}
					        	i++;
							});
							if (!(i==0)) {
					           	createImagen(inventarioArray,xOrt(player_h.x + 30,player_h.y),yOrt(player_h.x,player_h.y));
					            	inventarioH.delete(inventarioArray);
					            	inventario1H.delete(obtenerValorEtiqueta(inventarioArray,'nombre'));
					            indexInventarioH = 0; 
					            selectItemH(5,40,inventario1H,indexInventarioH,scene); 
				         }   
				        }
				    });
				    // Bajar opci�n en inventario F
				    this.input.keyboard.on('keyup', function (event) {
				        if (((event.keyCode === 114 || event.keyCode === 82) && cam3.visible) && ((personaje == 'humano')  || (personaje == "local")))
				        {	
				        	indexInventarioH++;
				        	if(indexInventarioH > inventario1H.size-1){
				            	indexInventarioH = 0;
				        	}
				        	selectItemH(5,40,inventario1H,indexInventarioH,scene);
				        }
				    });

				    // Subir opci�n en inventario R
				    this.input.keyboard.on('keyup', function (event) {
				        if (((event.keyCode === 102 || event.keyCode === 70) && cam3.visible) && ((personaje == 'humano')  || (personaje == "local")))
				        {	
				        	indexInventarioH--;
				        	if(indexInventarioH < 0){
				            	indexInventarioH = inventario1H.size-1;
				        	}
				        	selectItemH(5,40,inventario1H,indexInventarioH,scene);
				        }
				    });
				    // Abrir/Cerrar inventario E
					this.input.keyboard.on('keyup', function (event) {
				        if ((event.keyCode === 101 || event.keyCode === 69) && ((personaje == 'humano')  || (personaje == "local")))
				        {	
				            cam3.setVisible(!cam3.visible);
				        }
				    });

					//Teclado fantasma
					

					//Sacar inventario U
					this.input.keyboard.on('keyup', function (event) {
				        if ((event.keyCode === 117 || event.keyCode === 85) && (personaje == 'fantasma' || personaje == "local"))
				        {
					        if (personaje == 'fantasma') {
								var message = JSON.stringify({'Tipo' : 'datos' , 'Subtipo' : 'Inventario', 'indexInventarioOnline' : indexInventarioF });
								connection.send(message);
							}
				            var i = 0;
				            var inventarioArray;
				            inventarioF.forEach (function(value) {
					        	if(i == indexInventarioF){
						        	inventarioArray =  value;
					        	}
					        	i++;
							});
							if (!(i==0)) {
					           	createImagen(inventarioArray,xOrt(player_f.x + 30,player_f.y),yOrt(player_f.x,player_f.y));
					            	inventarioF.delete(inventarioArray);
					            	inventario1F.delete(obtenerValorEtiqueta(inventarioArray,'nombre'));
					            indexInventarioF = 0; 
					            selectItemF(445,40,inventario1F,indexInventarioF,scene);
				        	}
				        }
				    });
				    // Bajar opci�n en inventario H
				    this.input.keyboard.on('keyup', function (event) {
				        if (((event.keyCode === 104 || event.keyCode === 72) && cam4.visible)  && ((personaje == 'fantasma')   || (personaje == "local")))
				        {	
				        	indexInventarioF++;
				        	if(indexInventarioF > inventario1F.size-1){
				            	indexInventarioF = 0;
				        	}
				        	selectItemF(445,40,inventario1F,indexInventarioF,scene);
				        }
				    });

				    // Subir opci�n en inventario Y
				    this.input.keyboard.on('keyup', function (event) {
				        if (((event.keyCode === 121 || event.keyCode === 89) && cam4.visible) && ((personaje == 'fantasma')  || (personaje == "local")))
				        {	
				        	indexInventarioF--;
				        	if(indexInventarioF < 0){
				            	indexInventarioF = inventario1F.size-1;
				        	}
				        	selectItemF(445,40,inventario1F,indexInventarioF,scene);
				        }
				    });
					// Abrir/Cerrar inventario O
					this.input.keyboard.on('keyup', function (event) {
				        if ((event.keyCode === 111 || event.keyCode === 79)  && ((personaje == 'fantasma')  || (personaje == "local")))
				        {	
				            cam4.setVisible(!cam4.visible);
				        }
				    });
				    
					keyC = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.C);

					keyA = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A);
					keyS = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S);
					keyD = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D);
					keyW = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W);

					keyI = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.I);
					keyJ = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.J);
					keyK = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.K);
					keyL = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.L);
    },
    update: function() {
	
	 			//speed = 0.007 * delta;
	 			
	 			this.input.enabled = false;
    
    			function xIso(xO,yO){
					var xI;
					var txO = (xO - yO) * tileWidthHalf;
					xI = centerX + txO;
					return xI;
				}
				
				function yIso(xO,yO){
					var yI;
					var tyO = (xO + yO) * tileHeightHalf;
					yI = centerY + tyO;
					return yI;
				}

				function dIso(xO,yO,l){
					var dI;
					var tyO = (xO + yO) * tileHeightHalf;
					dI = (centerY + tyO)+(tileHeightHalf*l);
					return dI+l;
				}

				function xOrt(xI,yI){
					var xO,yO;

					yO= (((-xI + centerX)/tileWidthHalf) + ((yI-centerY)/tileHeightHalf))/2;
					xO= (xI - centerX + (yO*tileWidthHalf))/tileWidthHalf;
					return xO;
				}
				function yOrt(xI,yI){
					var yO;

					yO= (((-xI + centerX)/tileWidthHalf) + ((yI-centerY)/tileHeightHalf))/2;
					return yO;
				}
				
				function obtenerValorEtiqueta(cadena, etiqueta){
					while(cadena.length > 0){
						let indice = cadena.indexOf(";");
						if(indice == -1){
							return '';
						}
						let extraida = cadena.substring(0, indice);
						cadena = cadena.substring(indice+1,cadena.length);
						indice = extraida.indexOf("=");
						if(indice == -1){
							return '';
						}
						var extraida2 = extraida.substring(0, indice);
						if(extraida2 == etiqueta){
							return extraida.substring(indice+1,extraida.length);
						}
					}
					return '';
				}
				
				function createImagen(name,x,y){

					var object = matter.add.image(xIso(x,y), yIso(x,y), obtenerValorEtiqueta(name,'sprite'), 0, {
						                		isStatic: false,
						                		vertices:[{"x":0,"y":0}, 
						                                  {"x":15,"y":7}, 
						                                  {"x":30,"y":0}, 
						                                  {"x":15,"y":-7}],
						                	});
					object.depth = dIso(xOrt(object.x,object.y),yOrt(object.x,object.y),2);
					if(obtenerValorEtiqueta(name,'estatico') == 'si'){
						object.setStatic(true);
					}
					var category = obtenerValorEtiqueta(name,'categoria');
					if(category == 2){
						object.setCollisionCategory(cat2);
						object.setCollidesWith([ cat1, cat2, cat4 ]);
					}
					if(category == 3){
						object.setCollisionCategory(cat3);
						object.setCollidesWith([ cat1, cat3, cat4 ]);
					}
					if(category == 4){
						object.setCollisionCategory(cat4);
						object.setCollidesWith([ cat1, cat2, cat3, cat4 ]);
					}

					if(category == 5){
						object.setCollisionCategory(cat5);
						object.setCollidesWith([ cat2 ]);
					}
					if(category == 6){
						object.setCollisionCategory(cat6);
						object.setCollidesWith([ cat3 ]);
					}
					if(category == 7){
						object.setCollisionCategory(cat7);
						object.setCollidesWith([ cat2, cat3 ]);
					}


					object.name = name;
					objetosMapa.add(object); 
				}
				
				// Control del teclado para el Chat
					
					if ((chat == true) && (!(personaje=='local')))
					{	
						this.input.keyboard.enabled = false;
						this.input.keyboard.disableGlobalCapture();
					}
					if (chat == false) {					
						this.input.keyboard.enabled = true;
						this.input.keyboard.enableGlobalCapture();
					}  
					
			    // Muestra texto chat humano
				if ((!(mensaje == '')) && (personaje == "fantasma")) {	
					if (chatF.length > 4) {
						chatF.splice(0,1);					
					}	
					text_cTf.setText('');
					chatF[chatF.length]	= mensaje;
					for (var i = 0; i < chatF.length; i++) {
						if (i>0) {
					    	text_cTf.setText(text_cTf.text + '\n'+chatF[i]);
					    } else {
							text_cTf.setText(chatF[i]);
						}
					}
					mensaje = '';
					cam6.visible = true;
				}

				// Muestra texto chat del fantasma
				if ((!(mensaje == '')) && (personaje == "humano")) {	
					if (chatH.length > 4) {
						chatH.splice(0,1);					
					}	
					text_cTh.setText('');
					chatH[chatH.length]	= mensaje;
					for (var i = 0; i < chatH.length; i++) {
						if (i>0) {
					        text_cTh.setText(text_cTh.text + '\n'+chatH[i]);
					    } else {
							text_cTh.setText(chatH[i]);
						}    
					}
					mensaje = '';
					cam5.visible = true;
				}

			// Actualiza profundidad de los objetos

			objetosMapa.forEach (function(value) {
				if(!(obtenerValorEtiqueta(value.name,'depth') == "")){
					value.depth = dIso(xOrt(value.x,value.y),yOrt(value.x,value.y),parseFloat(obtenerValorEtiqueta(value.name,'depth')));
				}else{
						value.depth = dIso(xOrt(value.x,value.y),yOrt(value.x,value.y),2);
				}
			});
			
			player_h.depth = dIso(xOrt(player_h.x,player_h.y),yOrt(player_h.x,player_h.y),2);
			player_f.depth = dIso(xOrt(player_f.x,player_f.y),yOrt(player_f.x,player_f.y),2);
			
			//Teclas humano
			
			if ((personaje == 'humano') && (actualizaPersonaje == true)) {
				player_f.x = px;
				player_f.y = py;
				actualizaPersonaje = false;
			}
			
			//Sacar inventario onLine humano				
			if ((indexInventarioOnline >= 0) && (personaje == 'fantasma'))
		        {
		            var i = 0;
		            var inventarioArray;
		            inventarioH.forEach (function(value) {
			        	if(i == indexInventarioOnline){
				        	inventarioArray =  value;
			        	}
			        	i++;
					});
					if (!(i==0)) {
			           	createImagen(inventarioArray,xOrt(player_h.x + 30,player_h.y),yOrt(player_h.x,player_h.y));
			            	inventarioH.delete(inventarioArray);
			            	inventario1H.delete(obtenerValorEtiqueta(inventarioArray,'nombre')); 
		         } 
		        	indexInventarioOnline = -1;
		        }
												
			if ((personaje == 'humano')  || (personaje == "local")){
			    if (keyA.isDown)
			    {	
			        player_h.x = xIso(xOrt(player_h.x,player_h.y)- speed, yOrt(player_h.x,player_h.y)); 
			        player_h.y = yIso(xOrt(player_h.x,player_h.y)- speed, yOrt(player_h.x,player_h.y));
			        //player.anims.play('left', true);
			        if (!(personaje=='local')) {
				        var message = JSON.stringify({'Tipo' : 'datos' , 'Subtipo' : 'Posicion' , 'x' : player_h.x, 'y' : player_h.y});
						connection.send(message);
					}
			    }
			    else if (keyD.isDown)
			    {
			        player_h.x = xIso(xOrt(player_h.x,player_h.y)+ speed, yOrt(player_h.x,player_h.y)); 
			        player_h.y = yIso(xOrt(player_h.x,player_h.y)+ speed, yOrt(player_h.x,player_h.y)); 
			        //player.anims.play('right', true);
			        if (!(personaje=='local')) {
				        var message = JSON.stringify({'Tipo' : 'datos' , 'Subtipo' : 'Posicion' , 'x' : player_h.x, 'y' : player_h.y});
						connection.send(message);
					}
			    }
			    else if (keyW.isDown)
			    {
			        player_h.x = xIso(xOrt(player_h.x,player_h.y), yOrt(player_h.x,player_h.y)- speed); 
			        player_h.y = yIso(xOrt(player_h.x,player_h.y), yOrt(player_h.x,player_h.y)- speed);
			        //player.anims.play('down');
			        if (!(personaje=='local')) {
				        var message = JSON.stringify({'Tipo' : 'datos' , 'Subtipo' : 'Posicion' , 'x' : player_h.x, 'y' : player_h.y});
						connection.send(message);
					}
			    }

			    else if (keyS.isDown)
			    {
			        player_h.x = xIso(xOrt(player_h.x,player_h.y), yOrt(player_h.x,player_h.y)+ speed); 
			        player_h.y = yIso(xOrt(player_h.x,player_h.y), yOrt(player_h.x,player_h.y)+ speed);
			        //player.anims.play('up');
			        if (!(personaje=='local')) {
				        var message = JSON.stringify({'Tipo' : 'datos' , 'Subtipo' : 'Posicion' , 'x' : player_h.x, 'y' : player_h.y});
						connection.send(message);
					}
			    }else{
			    	player_h.anims.play('player_h', true);
			    }
			}


		    //Teclas fantasma
		    
		    if ((personaje == 'fantasma') && (actualizaPersonaje == true)){
				player_h.x = px;
				player_h.y = py;
				actualizaPersonaje = false;
			}
			
			//Sacar inventario onLine fantasma				
			if ((indexInventarioOnline >= 0) && (personaje == 'humano'))
		        {  
		            var i = 0;
		            var inventarioArray;
		            inventarioF.forEach (function(value) {
			        	if(i == indexInventarioOnline){
				        	inventarioArray =  value;
			        	}
			        	i++;
					});
					if (!(i==0)) {
			           	createImagen(inventarioArray,xOrt(player_f.x + 30,player_f.y),yOrt(player_f.x,player_f.y));
			            	inventarioF.delete(inventarioArray);
			            	inventario1F.delete(obtenerValorEtiqueta(inventarioArray,'nombre'));
		        	}
		        	indexInventarioOnline = -1;
		        }
			
			if  ((personaje == 'fantasma')  || (personaje == "local")){
			    if (keyJ.isDown)
			    {	
			        player_f.x = xIso(xOrt(player_f.x,player_f.y)- speed, yOrt(player_f.x,player_f.y)); 
			        player_f.y = yIso(xOrt(player_f.x,player_f.y)- speed, yOrt(player_f.x,player_f.y));
			        //player.anims.play('left', true);
			        if (!(personaje=='local')) {
				        var message = JSON.stringify({'Tipo' : 'datos' , 'Subtipo' : 'Posicion' , 'x' : player_f.x, 'y' : player_f.y});
						connection.send(message);
					}
			    }
			    else if (keyL.isDown)
			    {
			        player_f.x = xIso(xOrt(player_f.x,player_f.y)+ speed, yOrt(player_f.x,player_f.y)); 
			        player_f.y = yIso(xOrt(player_f.x,player_f.y)+ speed, yOrt(player_f.x,player_f.y)); 
			        //player.anims.play('right', true);
			        if (!(personaje=='local')) {
				        var message = JSON.stringify({'Tipo' : 'datos' , 'Subtipo' : 'Posicion' , 'x' : player_f.x, 'y' : player_f.y});
						connection.send(message);
					}
			    }
			    else if (keyI.isDown)
			    {
			        player_f.x = xIso(xOrt(player_f.x,player_f.y), yOrt(player_f.x,player_f.y)- speed); 
			        player_f.y = yIso(xOrt(player_f.x,player_f.y), yOrt(player_f.x,player_f.y)- speed);
			        //player.anims.play('down');
			        if (!(personaje=='local')) {
				        var message = JSON.stringify({'Tipo' : 'datos' , 'Subtipo' : 'Posicion' , 'x' : player_f.x, 'y' : player_f.y});
						connection.send(message);
					}
			    }

			    else if (keyK.isDown)
			    {
			        player_f.x = xIso(xOrt(player_f.x,player_f.y), yOrt(player_f.x,player_f.y)+ speed); 
			        player_f.y = yIso(xOrt(player_f.x,player_f.y), yOrt(player_f.x,player_f.y)+ speed);
			        //player.anims.play('up');
			        if (!(personaje=='local')) {
				        var message = JSON.stringify({'Tipo' : 'datos' , 'Subtipo' : 'Posicion' , 'x' : player_f.x, 'y' : player_f.y});
						connection.send(message);
					}
			    }else{
			    	player_f.anims.play('player_f', true);

			    }
			  }
			 
}
});