//Peticiones AJAX para la APIREST
    var name;
    var password;
    var contador;
    var ping = 1000;
    var inDB = false;
    var inParty = false;
    var countRequest;

    //Metodo Post
    function postPlayerSignIn(){
        $.ajax({
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            url: '/postNewPlayer',
            type: 'POST',
            dataType:"json",
            data:JSON.stringify({
                "name" :name,
                "password": password,
                "inDB":inDB,
            }),
            success: function(data) {
                console.log(data);
                if(data.inDB){
                  document.getElementById("title").innerHTML = "Player List :";
                  document.getElementById("Logger").innerHTML = "";
                  timeGetP = setInterval(getPlayers,ping);
                }else if(!data.inDB){
                  document.getElementById("title").innerHTML="Already Registered";
                  document.getElementById("username").value="";
                  document.getElementById("password").value="";
                }
                
            },
            error: function() {
                console.error("No es posible completar la operación");
            }
        });
    }

    function postPlayerLog(){
        $.ajax({
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                },
            url: '/postPlayer',
            type: 'POST',
            dataType:"json",
            data:JSON.stringify({
                "name" : name,
                "password": password,
                "inParty":inParty,
            }),
            success: function(data) {
                console.log(data);
                if(data.inParty){
                  if(data.reg){
                    document.getElementById("title").innerHTML = "Player List :";
                    document.getElementById("Logger").innerHTML = "";
                    timeGetP = setInterval(getPlayers,ping);
                  }else if (!data.reg){
                    document.getElementById("title").innerHTML="Not Registered";
                    document.getElementById("username").value="";
                    document.getElementById("password").value="";
                  }
                }else if(!data.inParty){
                  document.getElementById("title").innerHTML="Already Logged";
                  document.getElementById("username").value="";
                  document.getElementById("password").value="";
                }             
            },
            error: function() {
                console.error("No es posible completar la operación");
            }
        });
    }

    function setName(){
            name = document.getElementById("username").value;
    }

    function setPassword(){
            password = document.getElementById("password").value;
    }

    //Metodo delete
    function deletePlayer(){
        $.ajax({
            type: 'DELETE',
            headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                },
                url: '/deletePlayer',
                
                data:JSON.stringify({
                  "name":name,
                  "password":password,
              }),
              success: function(data){
                    console.log ("Se ha ido " + data.name)
              },
              error: function() {
                    console.error("No es posible completar la operación");
              }
        });
    }

    //Metodo Get
    function getPlayers(){
            $.ajax({
                url: '/getPlayers',
                type: 'GET',
                data:({
                    "name":name,
                    "password":password,
                }),
                success: function(data) {
                    document.getElementById("Logger").innerHTML = "";
                    if(data[0]!=null){
                        console.log("Jugador 1: " +data[0].name);
                        document.getElementById("Logger").innerHTML += data[0].name + '<br/>';
                    }

                    if(data[1]!=null){
                        console.log("Jugador 2: " +data[1].name);
                        document.getElementById("Logger").innerHTML += data[1].name;
                    }
                       countRequest=0;
                },
                error: function() {
                     if(countRequest<2){
                        console.error("No es posible completar la operación");
                        countRequest++;
                    }
                }

            });

        }

        function userSignIn(){
          $(document).ready(function() {
                  setName();
                  setPassword();
                  postPlayerSignIn();
          });
        }

        function userLog(){
          $(document).ready(function() {
              setName();
              setPassword();
              postPlayerLog();
          });
        }

         function deleteP(){
          $(document).ready(function() {
              setName();
              setPassword();
              deletePlayer();
          });
        }

        function numPlayers(){
          $.ajax({
                url:  '/numP',
                type: 'POST',
            success: function(){
               console.log("Sumado");
               preload = true;
             },
            error: function(){
              console.error("No es posible completar la operación");
            }
          });
        }

        function minusPlayers(){
          $.ajax({
                url: '/minusP',
                type: 'POST',
            success: function(){
               console.log("Restado");
             },
            error: function(){
              console.error("No es posible completar la operación");
            }
          });
        }

        function getOnlineP(){
          $.ajax({
                url: '/getP',
                type: 'GET',
                data:({
                  "cont":contador,
                }),
            success: function(data){
              document.getElementById("online").innerHTML = data;
             },
            error: function(){
              console.error("No es posible completar la operación");
            }
          });
        }