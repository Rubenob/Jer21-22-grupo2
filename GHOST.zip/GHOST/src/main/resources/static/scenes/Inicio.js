var Inicio = new Phaser.Class({
    Extends: Phaser.Scene,
        
    initialize: function() {
        Phaser.Scene.call(this, { "key": "Inicio" });
    },
    
    init: function() {},
    
    preload: function() {
	
        this.load.image('inicial', 'assets/image/pantalla_inicio.png');
        this.load.spritesheet('botonPublica', 'assets/image/botonPublica.png', { frameWidth: 256, frameHeight: 80 });
        this.load.spritesheet('botonPrivada', 'assets/image/botonPrivada.png', { frameWidth: 256, frameHeight: 80 });
        this.load.spritesheet('botonLocal', 'assets/image/botonLocal.png', { frameWidth: 256, frameHeight: 80 });
        
    },
    
    create: function() { 
		var bPublica;
	
		this.inicioImage = this.add.image(0,0, 'inicial').setOrigin(0,0);
    	bPublica = this.add.sprite(150, 230, 'botonPublica').setInteractive();
    	
    	bPublica.on('pointerdown', () => {
	      var message = JSON.stringify({'Tipo' : 'publica', 'Subtipo' : 'publica'});
		  connection.send(message);
		  juego.scene.stop('Inicio');
		  juego.scene.start('Espera',{codigo : 'Partida pública'});
	    });
	    
	    
	    bPrivada = this.add.sprite(430,230, 'botonPrivada').setInteractive();
    	
    	bPrivada.on('pointerdown', () => {
		  codigo=prompt('Ingrese el código para la partida privada:','');
		  if  (!(codigo == null || codigo == "")) {
		      var message = JSON.stringify({'Tipo' : 'privada', 'Subtipo' : codigo});
			  connection.send(message);
			  juego.scene.stop('Inicio');
			  juego.scene.start('Espera',{codigo : codigo});
		  }
	    });
	    
	    bLocal = this.add.sprite(710,230, 'botonLocal').setInteractive();
    	
    	bLocal.on('pointerdown', () => {
		  var message = JSON.stringify({'Tipo' : 'local', 'Subtipo' : 'cerrar'});
		  connection.send(message);
		  juego.scene.stop('Inicio');
		  juego.scene.start('Espera',{codigo : 'Partida local'});
	    });

    },
    
    update: function() {
    }
});