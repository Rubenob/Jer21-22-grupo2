var Espera = new Phaser.Class({
    Extends: Phaser.Scene,
    initialize: function() {
        Phaser.Scene.call(this, { "key": "Espera" });
    },
    init: function() {},
    preload: function() {
        this.load.image('esperando', 'assets/image/pantalla_espera.png');
    },
    create: function(datos) {
		this.esperaImage = this.add.image(0,0, 'esperando').setOrigin(0,0);
		text_cTes = this.add.text(15, 200, "",{ fontSize: '48px',fill:'#000', fontStyle: 'bold' });
	    text_cTes.setText('Código: '+datos.codigo);
	    
    },
    update: function() {
	}
});