var Fin = new Phaser.Class({
    Extends: Phaser.Scene,
    initialize: function() {
        Phaser.Scene.call(this, { "key": "Fin" });
    },
    init: function() {},
    preload: function() {
        this.load.image('final', 'assets/image/pantalla_fin.png');
    	console.log('preload fin');
    },
    create: function() { 
		this.finImage = this.add.image(0,0, 'final').setOrigin(0,0);
    	console.log('create fin');
    },
    update: function() {
	}
});