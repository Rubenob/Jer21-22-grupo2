package com.urjc;


import org.json.JSONObject;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;
import java.util.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;



public class WebsocketHandler extends TextWebSocketHandler {
	
	class Usuario{  
		WebSocketSession Sesion;  
	    String Grupo;
	    String Personaje;
	    Usuario(WebSocketSession Sesion,String Grupo, String Personaje){  
	        this.Sesion=Sesion;  
	        this.Grupo=Grupo;
	        this.Personaje = Personaje;
	    }
	}
	  	
	
	ArrayList<Usuario> Usuarios = new ArrayList<>();
	
	
	@Override
	protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
		
		System.out.println("Message received: " + message.getPayload());
		
		int idUsuario = 0;
		JSONObject myMsg = new JSONObject();
		
		/* Sacamos los valores del mensaje */
		String payload = message.getPayload();
		JSONObject jsonObject = new JSONObject(payload);
		String Tipo = jsonObject.getString("Tipo");
		String Mensaje = jsonObject.getString("Subtipo");
		
		/* Vemos si es una nueva conexión. Si no existe la añadimos como nueva conexión. */
		//System.out.println("Buscando si existe sesión. "+session);
		boolean Encontrado = false;
		for (int i=0;i<Usuarios.size();i++) {
            if (Usuarios.get(i).Sesion.equals(session)) {
            	Encontrado = true;
            	idUsuario = i;
            	//System.out.println("Sesión encontrada.");
            }
        }
        if (!Encontrado) {
        	if (Tipo.equals("conexionNueva")) {
	        	Usuarios.add(new Usuario(session,"conexionNueva","sinDefinir"));
	        	//System.out.println("Añadida nueva sesión. ");
	        	return;
        	} else {
        		//System.out.println("Error de petición en la conexión. "+session+" "+Tipo);
        		myMsg.put("Tipo", "Error");
            	myMsg.put("Mensaje", "Solicitud de conexión no esperada.");
        		session.sendMessage(new TextMessage(myMsg.toString()));
        		session.close();
        		return;
        	}
        }
                		
		/* Control de sesiones públicas */
		if ((Tipo.equals("publica"))  && (Usuarios.get(idUsuario).Grupo.equals("conexionNueva"))) {
			//System.out.println("Buscando sesiones públicas.");
			Encontrado = false;
			for (int i=0;i<Usuarios.size();i++) {
	            if ((Usuarios.get(i).Grupo.equals("publica")) && (!Usuarios.get(i).Sesion.equals(session))) {	            	
	            	if (Usuarios.get(i).Sesion.isOpen()) {
		            	Encontrado = true;
		            	String idGrupo = LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME);
		            	Usuarios.get(i).Grupo = idGrupo;
		            	Usuarios.get(i).Personaje = "fantasma";
		            	for (int j=0;j<Usuarios.size();j++) {
		    	            if ((Usuarios.get(j).Sesion.equals(session))){
		    	            	Usuarios.get(j).Grupo = idGrupo;
		    	            	Usuarios.get(j).Personaje = "humano";
		    	            }
		            	}
		            	//System.out.println("Grupo creado. "+idGrupo);
		            	myMsg.put("Tipo", "Comienzo");
		            	myMsg.put("Mensaje", "Partida pública.");
		            	myMsg.put("Grupo", idGrupo);
		            	myMsg.put("Personaje", "fantasma");
		            	Usuarios.get(i).Sesion.sendMessage(new TextMessage(myMsg.toString()));
		            	myMsg.put("Personaje", "humano");
		            	session.sendMessage(new TextMessage(myMsg.toString()));
		            	return;
	            	}
	            }
	        }
	        if (!Encontrado) {
        		for (int j=0;j<Usuarios.size();j++) {
    	            if (((Usuarios.get(j).Sesion.equals(session))) && (!Usuarios.get(j).Grupo.equals("publica"))){
    	            	Usuarios.get(j).Grupo = "publica";
    	            	Usuarios.get(j).Personaje = "humano";
    	            	myMsg.put("Tipo", "Esperando");
    	            	myMsg.put("Mensaje", "Esperando otro usuario.");
    	            	myMsg.put("Personaje", "humano");
    	            	Usuarios.get(j).Sesion.sendMessage(new TextMessage(myMsg.toString()));
    	            	//System.out.println("Sesión pública. Esperando otro usuario.");
    	            	return;
    	            }
            	}        		
	        }			
		}
		
		/* Control de sesiones privadas */
		if ((Tipo.equals("privada"))  && (Usuarios.get(idUsuario).Grupo.equals("conexionNueva"))) {
			//System.out.println("Buscando sesiones privadas.");
			Encontrado = false;
			for (int i=0;i<Usuarios.size();i++) {
	            if ((Usuarios.get(i).Grupo.equals(Mensaje)) && (!Usuarios.get(i).Sesion.equals(session))) {	            	
	            	if (Usuarios.get(i).Sesion.isOpen()) {
		            	Encontrado = true;
		            	String idGrupo = LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME);
		            	Usuarios.get(i).Grupo = idGrupo;
		            	Usuarios.get(i).Personaje = "fantasma";
		            	for (int j=0;j<Usuarios.size();j++) {
		    	            if ((Usuarios.get(j).Sesion.equals(session))){
		    	            	Usuarios.get(j).Grupo = idGrupo;
		    	            	Usuarios.get(j).Personaje = "humano";
		    	            }
		            	}
		            	//System.out.println("Grupo creado.");
		            	myMsg.put("Tipo", "Comienzo");
		            	myMsg.put("Mensaje", "Partida privada.");
		            	myMsg.put("Grupo", idGrupo);
		            	myMsg.put("Personaje", "fantasma");
		            	Usuarios.get(i).Sesion.sendMessage(new TextMessage(myMsg.toString()));
		            	myMsg.put("Personaje", "humano");
		            	session.sendMessage(new TextMessage(myMsg.toString()));
		            	return;
	            	}
	            }
	        }
	        if (!Encontrado) {
        		for (int j=0;j<Usuarios.size();j++) {
    	            if (((Usuarios.get(j).Sesion.equals(session))) && (!Usuarios.get(j).Grupo.equals("privado"))){
    	            	Usuarios.get(j).Grupo = Mensaje;
    	            	Usuarios.get(j).Personaje = "humano";
    	            	myMsg.put("Tipo", "Esperando");
    	            	myMsg.put("Mensaje", "Esperando otro usuario.");
    	            	myMsg.put("Personaje", "humano");            	
    	            	Usuarios.get(j).Sesion.sendMessage(new TextMessage(myMsg.toString()));
    	            	//System.out.println("Creada una sesión privada. Esperando a otro usuario.");
    	            	return;
    	            }
            	}        		
	        }			
		}
		
		/* Partida en modo local. */
		if (Tipo.equals("local")) {
			//System.out.println("Partida local.");
			for (int j=0;j<Usuarios.size();j++) {
				 if (Usuarios.get(j).Sesion.equals(session)){
					       //System.out.println("Sesión cerrada.");
			 		       myMsg.put("Tipo", "Local");
		    	           myMsg.put("Mensaje", "Partida en modo local.");
			 		       Usuarios.get(j).Sesion.sendMessage(new TextMessage(myMsg.toString()));
			 		       Usuarios.remove(j);
			 		 }
				 }
		}
		
		
		/* Enviamos datos al otro cliente del mismo grupo. */
		if (Tipo.equals("datos")) {
			//System.out.println("Enviando mensaje de datos.");
			for (int j=0;j<Usuarios.size();j++) {
				 if ((!(idUsuario == j)) && (Usuarios.get(j).Grupo.equals(Usuarios.get(idUsuario).Grupo))){
					 if (Usuarios.get(j).Sesion.isOpen()) {
						 myMsg.put("Tipo", "Datos");
	    	             myMsg.put("Mensaje", "Datos de usuario.");
	    	             myMsg.put("Personaje", Usuarios.get(j).Personaje);
	    	             myMsg.put("Datos", payload);
						 Usuarios.get(j).Sesion.sendMessage(new TextMessage(myMsg.toString()));
					 } else {
			 		       //System.out.println("Sesión cerrada, eliminando ambas sesiones.");
			 		       myMsg.put("Tipo", "Cerrado");
		    	           myMsg.put("Mensaje", "El otro usuario cerró la sesión.");
			 		       Usuarios.get(idUsuario).Sesion.sendMessage(new TextMessage(myMsg.toString()));
			 		       Usuarios.remove(j);
			 		       Usuarios.remove(idUsuario);
			 		 }
				 }
	        }
		}
		
		
	}
}