package com.urjc;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoginRestController {
	
	int contador = 0;
		
	private Map<String, Jugador> Jugadores = new ConcurrentHashMap<>();
	
	
	//DataBase stuff.
	private String bd_path = "src\\main\\resources\\data_base.txt";
	File bdFile = new File(bd_path);
	
	BufferedReader br;
	BufferedWriter bw;
	
	BufferedReader br1;
	
	//End of database stuff.
			
	@PostMapping("/postNewPlayer")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<Jugador> newJugador(@RequestBody Jugador Jugador,HttpServletRequest request) {
		
		if(!InDB(Jugador)) {
			if(!Jugadores.containsKey(Jugador.getName())) {
				Jugadores.put(Jugador.getName(), Jugador);
				Jugadores.put(Jugador.getPassword(), Jugador);
				//Database stuff.
				try {
					bw = new BufferedWriter(new FileWriter(bdFile, true));
					bw.write( Jugador.getName() + "  " + Jugador.getPassword());
					bw.newLine();
					bw.close();
				}catch(IOException e) {
					System.out.println(e.toString());
				}
				Jugador.setInDB(true);
				Jugadores.put(Jugador.getName(), Jugador);
				return new ResponseEntity<>(Jugador, HttpStatus.OK);
			}
			else { 
				return new ResponseEntity<>(Jugador,HttpStatus.CONFLICT);
			}
		}else if(InDB(Jugador)) {
			Jugador.setInDB(false);
			return new ResponseEntity<>(Jugador, HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(Jugador,HttpStatus.CONFLICT);
		}
	}
	
	@PostMapping("/postPlayer")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<Jugador> JugadorLog(@RequestBody Jugador Jugador,HttpServletRequest request) {
			if(!InParty(Jugador)) {
				boolean registered = false;
				String nameAux = Jugador.getName();
				String passAux = Jugador.getPassword();
				String logAux = nameAux + "  " + passAux;
				try {
					br1 = new BufferedReader(new FileReader(bdFile));
					String line;
					while((line = br1.readLine()) != null && registered == false) {
						if(logAux.equals(line)) {
							registered=true;
						}
					}
					br1.close();
				}catch(IOException e) {
					System.out.println(e.toString());
				}
				if(registered) {
					Jugador.setReg(registered);
					Jugadores.put(Jugador.getName(), Jugador);
				}
				Jugador.setInParty(true);
				return new ResponseEntity<>(Jugador, HttpStatus.OK);
			}else if(InParty(Jugador)){
				Jugador.setInParty(false);
				return new ResponseEntity<>(Jugador, HttpStatus.OK);
			}
			else { 
				return new ResponseEntity<>(Jugador,HttpStatus.CONFLICT);
			}	
	}
	
	@GetMapping("/bd")
	public List<String> readBD() {
		
		List<String> Jugadoress = new LinkedList<String>();
		
		try {
			br = new BufferedReader(new FileReader(bdFile));
			String line;
			while((line = br.readLine()) != null) {
				Jugadoress.add(line);
			}
			br.close();
		}catch(Exception e) {
			System.out.println(e.toString());
		}
		
		return Jugadoress;
	}
	
	
	@GetMapping("/getPlayers")
	public Collection<Jugador> JugadoresList(@RequestParam String name) {
			Iterator<Jugador> playersCollectIterator= Jugadores.values().iterator();
			Jugador player;	
			while(playersCollectIterator.hasNext()) {
				player=playersCollectIterator.next();
				return Jugadores.values();
			}
			return Jugadores.values();
	}
	
	
	@DeleteMapping("/deletePlayer")
	public ResponseEntity<Jugador> deleteJugador(@RequestBody Jugador Jugador,HttpServletRequest request) {
			Jugadores.remove(Jugador.getName());
            System.out.println("El jugador ': " + Jugador.getName() + "'ha sido eliminado");
            return new ResponseEntity<>(Jugador, HttpStatus.OK);
    }

	@PostMapping("/numP")
	@CrossOrigin(origins = "*")
	public void numP() {
		contador++;
	}
	
	@PostMapping("/minusP")
	@CrossOrigin(origins = "*")
	public void minusP() {
            if (contador > 0)
		contador--;
	}
	
	@GetMapping("/getP")
	@CrossOrigin(origins = "*")
	public int getP() {
		return contador;
	}
	
	public boolean InDB(Jugador Jugador) {
		boolean in = false;
		String nameAux = Jugador.getName();
		String passAux = Jugador.getPassword();
		String logAux = nameAux + "  " + passAux;
		try {
			br1 = new BufferedReader(new FileReader(bdFile));
			String line;
			while((line = br1.readLine()) != null && in == false) {
				if(logAux.equals(line)) {
					in=true;
				}
			}
			br1.close();
		}catch(IOException e) {
			System.out.println(e.toString());
		}
		
		return in;
	}
	
	public boolean InParty(Jugador Jugador) {
		boolean in = false;
		String nameAux = Jugador.getName();
		Iterator<Jugador> it=Jugadores.values().iterator();
		while(it.hasNext()) {
			 Jugador Jugadoraux = it.next();
			if(nameAux.equals(Jugadoraux.getName())) {
				in = true;
			}
		}
		return in;
	}
}


