package com.urjc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@SpringBootApplication
@EnableWebSocket
public class GhostApplication implements WebSocketConfigurer {

	@Override
	public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
		registry.addHandler(Handler(), "/echo")
			.setAllowedOrigins("*");
	}
	
	@Bean
	public WebsocketHandler Handler() {
		return new WebsocketHandler();
	}
	public static void main(String[] args) {
		SpringApplication.run(GhostApplication.class, args);
	}

}
