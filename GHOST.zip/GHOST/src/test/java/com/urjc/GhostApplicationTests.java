package com.urjc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GhostApplicationTests {

	@Test
	void contextLoads() {
	}

}
